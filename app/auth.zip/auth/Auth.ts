import AppUser from '../db/Models/AppUser';
import argon2 from 'argon2';
import jwt, { JwtPayload } from 'jsonwebtoken';
import Env from '../../env';

export default class Auth {
    static async signUp(login:string, password:string){
        const hashedPassword = await argon2.hash(password);
        const result = await AppUser.create(login,hashedPassword);
        if(!result) throw new AuthUserCreateError();
        return new AuthInfo(result);
    }
    static async signIn(login:string, password:string){
        const user = await AppUser.find({ login });
        if(!user) throw new AuthUserNotExistsError();
        const passIsCorect = await argon2.verify(user.password, password);
        if(!passIsCorect) throw new AuthUserIncorrectPasswordError();
        return new AuthInfo(user);
    }
    static async getUserBy(token:string){
        const user = await AppUser.find({ password:token });
        if(!user) throw new AuthUserNotExistsError();
        const tokenIsCorect = await jwt.verify(token, Env.AUTH_SECRET);
        if(!tokenIsCorect) throw new InvalidTokenError();
        return new AuthInfo(user, token);
    }
    static async update(token:string){
        if(!jwt.verify(token, Env.AUTH_SECRET)) throw new InvalidTokenError();
        const decoded = jwt.decode(token) as { data:any };
        const data = AppUser.safeData(decoded?.data);
        if(!data.id || !data.login) throw new InvalidTokenError();
        const user = await AppUser.find({ id:data.id });
        if(!user) throw new AuthUserNotExistsError();
        return new AuthInfo(user, token);
    }
}
export class AuthInfo{
    readonly _user:AppUser;
    readonly token:string;
    get safeData(){
        return {
            user:this._user.safeData,
            token:this.token
        }
    }
    constructor(user:AppUser, token?:string){
        this._user = user;
        this.token = token || this.generateToken();
    }
    private generateToken() {
        return jwt.sign({ data:this._user.safeData }, Env.AUTH_SECRET, { expiresIn: Env.AUTH_EXPIRATION });
    }
}
export class AuthUserNotExistsError extends Error{}
export class AuthUserIncorrectPasswordError extends Error{}
export class AuthUserCreateError extends Error{}
export class InvalidTokenError extends Error{}