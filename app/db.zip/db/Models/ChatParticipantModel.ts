import { DataTypes } from "sequelize";
import { Column, Table } from "sequelize-typescript";
import Model from "sequelize/types/model";
import DB from "../DB";
import AppUser from "./AppUser";
import ChatParticipantRole from "./ChatParticipantRole";
import ChatTypes from "./ChatTypes";

@Table
export default class ChatParticipant extends Model{
    @Column({
        type:DataTypes.INTEGER,
        autoIncrement:true,
        primaryKey:true
    })
    id:number = 0;
    @Column({
        type:DataTypes.STRING
    })
    chat:string = "";
    @Column({
        type:DataTypes.INTEGER,
        references:{
            model:ChatParticipantRole,
            key:"id"
        }
    })
    role:number = 0;
    @Column({
        type:DataTypes.INTEGER,
        references:{
            model:AppUser
        }
    })
    appUser:number = 0
}