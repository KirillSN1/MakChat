import DB from "../DB";
import { AlreadyExistsError } from "./ModelsError";

class InvalidDataError extends Error{}
export default class AppUser{
    readonly id:number = 0;
    readonly login:string = "";
    readonly password:string = "";
    constructor({ id = 0, login = "", password = "" }){
        if(id == 0 || !login || !password) throw new InvalidDataError("Invalid data.");
        this.id = id;
        this.login = login;
        this.password = password;
    }
    static parse(data?:{ id?:number, login?:string, password?:string }){
        if(!data || !data.id || !data.login || !data.password) return null;
        return new AppUser(data);
    }
    get safeData(){
        return AppUser.safeData(this);
    }
    static safeData(data:AppUser){
        return {
            id:data?.id || 0,
            login:data?.login || ""
        };
    }
    /**
     * 
     * @param login 
     * @param password 
     * @returns 
     * @throws {@link AlreadyExistsError } В случае, если пользователь  с таким логином уже существует
     */
    static async create(login:string, password:string){
        const client = DB.connect();
        if(await this.find({ login })) throw new AlreadyExistsError("User with this login already exists!");
        const result = await client.query(`INSERT INTO "AppUsers" ("login","password") VALUES ('${login}', '${password}');`);
        return this.find({ login, password });
    }
    static async find(data:{ id?:number, login?:string, password?:string }){
        const client = DB.connect();
        var sql = `SELECT * FROM "AppUsers" WHERE` + Object.entries(data).map(param=>`"${param[0]}"='${param[1]}'`).join(" AND ");
        const result = await client.query(sql);
        return AppUser.parse(result.rows[0]);
    }
}