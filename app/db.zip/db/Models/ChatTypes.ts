import { DataTypes } from "sequelize";
import { Column, Table } from "sequelize-typescript";
import Model from "sequelize/types/model";
import DB from "../DB";

@Table
export default class ChatTypes extends Model{
    @Column({
        type:DataTypes.INTEGER,
        autoIncrement:true,
        primaryKey:true
    })
    id:number = 0;
    @Column({
        type:DataTypes.STRING,
        allowNull:true
    })
    name:string | null = null;
    @Column(DataTypes.STRING)
    title:string = ""
}
// ChatTypes.init({
//     id:{
//         type:DataTypes.INTEGER,
//         autoIncrement:true,
//         primaryKey:true
//     },
//     name:{
//         type:DataTypes.STRING,
//         allowNull:true
//     },
//     title:{
//         type:DataTypes.STRING,
//     }
// }, { sequelize:DB.sequelize });