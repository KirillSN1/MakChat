import { DataTypes } from "sequelize";
import { Column, Table } from "sequelize-typescript";
import Model from "sequelize/types/model";
import DB from "../DB";
import ChatTypes from "./ChatTypes";

@Table
export default class ChatParticipantRole extends Model{
    @Column({
        type:DataTypes.INTEGER,
        autoIncrement:true,
        primaryKey:true
    })
    id:number = 0;
    @Column(DataTypes.STRING)
    name:string = "";
    @Column({
        type:DataTypes.INTEGER,
        references:{
            model:ChatTypes,
            key:"id"
        }
    })
    type:number = 0
}
// ChatParticipantRole.init({
//     id:{
//         type:DataTypes.INTEGER,
//         autoIncrement:true,
//         primaryKey:true
//     },
//     name:{
//         type:DataTypes.STRING
//     },
//     type:{
//         type:DataTypes.INTEGER,
//         references:{
//             model:ChatTypes,
//             key:"id"
//         }
//     }
// }, { sequelize:DB.sequelize });