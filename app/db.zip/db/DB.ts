import Env from '../../env';
import { Client } from 'pg'
export default class DB{
    static client:Client;
    static connect(){
        if(this.client) return this.client;
        this.client = new Client({
            host:Env.HOST,
            database:Env.PGDATABASE,
            password:Env.PGPASSWORD,
            port:Env.PGPORT,
            user:Env.PGUSER
        });
        this.client.connect();
        return this.client;
    }
}